package models

import (
	"fmt"
	"server/config"
)

type PesertaCimpa struct {
	Nama         string `json:"nama"`
	Klasis       string `json:"klasis"`
	Runggun      string `json:"runggun"`
	IdPeserta    string `json:"id_peserta"`
	JenisKelamin string `json:"jenis_kelamin"`
	NoTelp       string `json:"no_telp"`
	LinkSosmed   string `json:"link_sosmed"`
	Foto         string `json:"foto"`
	// IsConfirmed  bool   `json:"is_confirmed"`
}

type PesertaCimpaDetail struct {
	Id           string `json:"id"`
	Nama         string `json:"nama"`
	Klasis       string `json:"klasis"`
	Runggun      string `json:"runggun"`
	IdPeserta    string `json:"id_peserta"`
	JenisKelamin string `json:"jenis_kelamin"`
	NoTelp       string `json:"no_telp"`
	LinkSosmed   string `json:"link_sosmed"`
	Foto         string `json:"foto"`
	IsConfirmed  bool   `json:"is_confirmed"`
}

type PesertaCimpaResult struct {
	Nama         string `json:"nama"`
	Klasis       string `json:"klasis"`
	Runggun      string `json:"runggun"`
	IdPeserta    string `json:"id_peserta"`
	JenisKelamin string `json:"jenis_kelamin"`
	NoTelp       string `json:"no_telp"`
	LinkSosmed   string `json:"link_sosmed"`
	Foto         string `json:"foto"`
}

type BuktiBayarResult struct {
	Id         string `json:"id"`
	BuktiBayar string `json:"bukti_bayar"`
	Klasis     string `json:"klasis"`
	Status     string `json:"status"`
}

type IdPeserta struct {
	Id string `json:"id"`
}

type BuktiBayarInput struct {
	Id      string `json:"id"`
	Message string `json:"message"`
}

func CreatePeserta(od PesertaCimpa) (PesertaCimpa, error) {

	//insert values
	sqlStr := "INSERT into peserta_cimpa(nama, klasis, runggun, id_peserta, jenis_kelamin, no_telp, link_sosmed, foto, is_confirmed) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)"

	stmt, err := config.DB.Prepare(sqlStr)
	checkErr(err)
	fmt.Println("CHECKPOINT")
	_, err = stmt.Exec(od.Nama, od.Klasis, od.Runggun, od.IdPeserta, od.JenisKelamin, od.NoTelp, od.LinkSosmed, od.Foto, 0)
	checkErr(err)

	return od, nil
}

func UpdateStatusKonfirmasiPeserta(id string) error {
	//update value
	sqlStr := "UPDATE peserta_cimpa SET is_confirmed=1 WHERE id=?"
	stmt, err := config.DB.Prepare(sqlStr)
	if err != nil {
		fmt.Println(err)
		return err
	}
	_, err = stmt.Exec(id)
	if err != nil {
		fmt.Println(err)
		return err
	}

	return nil
}

func UpdateBuktiBayar(url string, klasis string) error {
	//update value
	sqlStr := "INSERT INTO bukti_bayar (bukti_bayar, klasis, status) VALUES(?,?,?)"
	stmt, err := config.DB.Prepare(sqlStr)
	if err != nil {
		fmt.Println(err)
		return err
	}
	_, err = stmt.Exec(url, klasis, "MENUNGGU KONFIRMASI")
	if err != nil {
		fmt.Println(err)
		return err
	}

	return nil
}

func DeleteBuktiBayarID(id string) error {
	//delete value
	sqlStr := "DELETE FROM bukti_bayar WHERE id=?"
	stmt, err := config.DB.Prepare(sqlStr)
	if err != nil {
		fmt.Println(err)
		return err
	}
	_, err = stmt.Exec(id)
	if err != nil {
		fmt.Println(err)
		return err
	}

	return nil

}

func GetPesertaCimpaByID(id string) (PesertaCimpaResult, error) {
	//select peserta
	sqlStr := "SELECT nama, klasis, runggun, id_peserta, jenis_kelamin, no_telp, link_sosmed, foto FROM peserta_cimpa WHERE id=?"
	stmt, err := config.DB.Prepare(sqlStr)
	checkErr(err)
	var peserta PesertaCimpaResult
	err = stmt.QueryRow(id).Scan(&peserta.Nama, &peserta.Klasis, &peserta.Runggun, &peserta.IdPeserta, &peserta.JenisKelamin, &peserta.NoTelp, &peserta.LinkSosmed, &peserta.Foto)
	checkErr(err)

	return peserta, nil
}

func GetAllPesertaCimpa() ([]PesertaCimpaDetail, error) {
	//select peserta
	sqlStr := "SELECT id, nama, klasis, runggun, id_peserta, jenis_kelamin, no_telp, link_sosmed, foto, is_confirmed FROM peserta_cimpa"
	stmt, err := config.DB.Prepare(sqlStr)
	checkErr(err)
	var allPeserta []PesertaCimpaDetail
	// err = stmt.Query(klasis).Scan(&peserta.Nama, &peserta.Klasis, &peserta.Runggun, &peserta.IdPeserta, &peserta.JenisKelamin, &peserta.NoTelp, &peserta.LinkSosmed, &peserta.Foto)
	rows, err := stmt.Query()
	checkErr(err)

	for rows.Next() {
		var peserta PesertaCimpaDetail
		if err := rows.Scan(&peserta.Id, &peserta.Nama, &peserta.Klasis, &peserta.Runggun,
			&peserta.IdPeserta, &peserta.JenisKelamin, &peserta.NoTelp,
			&peserta.LinkSosmed, &peserta.Foto, &peserta.IsConfirmed); err != nil {
			panic(err)
		}
		allPeserta = append(allPeserta, peserta)
	}

	if err = rows.Err(); err != nil {
		panic(err)
	}

	return allPeserta, nil
}

func GetAllBuktiBayar() ([]BuktiBayarResult, error) {
	//select peserta
	sqlStr := "SELECT id, bukti_bayar, klasis, status FROM bukti_bayar"
	stmt, err := config.DB.Prepare(sqlStr)
	checkErr(err)
	var allBukti []BuktiBayarResult
	// err = stmt.Query(klasis).Scan(&peserta.Nama, &peserta.Klasis, &peserta.Runggun, &peserta.IdPeserta, &peserta.JenisKelamin, &peserta.NoTelp, &peserta.LinkSosmed, &peserta.Foto)
	rows, err := stmt.Query()
	checkErr(err)

	for rows.Next() {
		var bukti BuktiBayarResult
		if err := rows.Scan(&bukti.Id, &bukti.BuktiBayar, &bukti.Klasis, &bukti.Status); err != nil {
			panic(err)
		}
		allBukti = append(allBukti, bukti)
	}

	if err = rows.Err(); err != nil {
		panic(err)
	}

	return allBukti, nil
}

func GetAllPesertaCimpaByKlasis(klasis string) ([]PesertaCimpaDetail, error) {
	//select peserta
	sqlStr := "SELECT id, nama, klasis, runggun, id_peserta, jenis_kelamin, no_telp, link_sosmed, foto, is_confirmed FROM peserta_cimpa WHERE klasis=?"
	stmt, err := config.DB.Prepare(sqlStr)
	checkErr(err)
	var allPeserta []PesertaCimpaDetail
	// err = stmt.Query(klasis).Scan(&peserta.Nama, &peserta.Klasis, &peserta.Runggun, &peserta.IdPeserta, &peserta.JenisKelamin, &peserta.NoTelp, &peserta.LinkSosmed, &peserta.Foto)
	rows, err := stmt.Query(klasis)
	checkErr(err)

	for rows.Next() {
		var peserta PesertaCimpaDetail
		if err := rows.Scan(&peserta.Id, &peserta.Nama, &peserta.Klasis, &peserta.Runggun,
			&peserta.IdPeserta, &peserta.JenisKelamin, &peserta.NoTelp,
			&peserta.LinkSosmed, &peserta.Foto, &peserta.IsConfirmed); err != nil {
			panic(err)
		}
		allPeserta = append(allPeserta, peserta)
	}

	if err = rows.Err(); err != nil {
		panic(err)
	}

	return allPeserta, nil
}

func GetBuktiBayarByKlasis(klasis string) ([]BuktiBayarResult, error) {
	//select peserta
	sqlStr := "SELECT id, bukti_bayar, klasis, status FROM bukti_bayar WHERE klasis=?"
	stmt, err := config.DB.Prepare(sqlStr)
	checkErr(err)
	var allBukti []BuktiBayarResult
	// err = stmt.Query(klasis).Scan(&peserta.Nama, &peserta.Klasis, &peserta.Runggun, &peserta.IdPeserta, &peserta.JenisKelamin, &peserta.NoTelp, &peserta.LinkSosmed, &peserta.Foto)
	rows, err := stmt.Query(klasis)
	checkErr(err)

	for rows.Next() {
		var bukti BuktiBayarResult
		if err := rows.Scan(&bukti.Id, &bukti.BuktiBayar, &bukti.Klasis, &bukti.Status); err != nil {
			panic(err)
		}
		allBukti = append(allBukti, bukti)
	}

	if err = rows.Err(); err != nil {
		panic(err)
	}

	return allBukti, nil
}

func ChangeStatusBuktiBayar(id string, message string) error {
	//update value
	sqlStr := "UPDATE bukti_bayar SET status=? WHERE id=?"
	stmt, err := config.DB.Prepare(sqlStr)
	if err != nil {
		fmt.Println(err)
		return err
	}
	_, err = stmt.Exec(message, id)
	if err != nil {
		fmt.Println(err)
		return err
	}

	return nil
}

func DeleteAllPeserta() error {
	//delete all peserta
	sqlStr := "Truncate TABLE peserta_cimpa"
	stmt, err := config.DB.Prepare(sqlStr)
	checkErr(err)

	stmt.Exec()
	checkErr(err)

	return nil
}

func checkErr(err error) {
	if err != nil {
		panic(err)
	}
}
